
// Initialize Firebase
app.config(function() {
  var config = {
    apiKey: "AIzaSyBo6zGO2sshtRkIIn1FtLG2eIXQcNs5o-A",
    authDomain: "ionicrevolution-77640.firebaseapp.com",
    databaseURL: "https://ionicrevolution-77640.firebaseio.com",
    storageBucket: "ionicrevolution-77640.appspot.com",
  };
  firebase.initializeApp(config);
  
      // Get a reference to the storage service, which is used to create references in your storage bucket
 // var storage = firebase.storage();

  // Create a storage reference from our storage service
//  var storageRef = storage.ref();
});