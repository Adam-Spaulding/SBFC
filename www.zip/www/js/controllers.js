function init() {
  window.initGapi(); // Calls the init function defined on the window
}

var app = angular.module('revolution.controllers', ['firebase', 'ngCordova', 'ngMap', 'ngResource']);

app.controller('AppCtrl', function ($scope, $rootScope, $timeout, $state, $ionicLoading, $ionicSideMenuDelegate, $ionicHistory, FirebaseUser, $firebaseAuth, $firebaseObject) {

  // side menu open/closed - changing navigation icons
  $scope.$watch(function () {
    return $ionicSideMenuDelegate.getOpenRatio();
  },
    function (ratio) {
      if (ratio === 1 || ratio === -1) {
        $scope.isActive = true;
      } else {
        $scope.isActive = false;
      }
    });

  // go back button
  $scope.back = function () {
    $ionicHistory.goBack();
  }

  $scope.getUserStatus = function () {
    // get firebase user
    var user = FirebaseUser.status();
    if (user) {
      $rootScope.user = user.email;
      $rootScope.userUid = user.uid;
    } else {
      $rootScope.user = 'Anonymous';
      $rootScope.userUid = 0;
    }
  }

  $scope.$watch(
    function ($scope) {
      return ($scope.getUserStatus());
    },
    function (newValue) {
    }
  );

  $scope.logout = function () {
    $firebaseAuth().$signOut();
    $timeout(function () {
      $scope.getUserStatus();
      $state.go('app.login');
    }, 100)
  }


  // USER PROFILE
  $scope.getUserProfile = function (uid) {
    var refArray = firebase.database().ref().child("users").child($rootScope.userUid);
    $scope.userProfile = $firebaseObject(refArray);
    $state.go('app.profile');
  }


  // RIGHT SIDE MENU NOTIFICATIONS

  $scope.data = {
    showDelete: true
  };

  $scope.edit = function (item) {
    alert('Edit Item: ' + item.id);
  };
  $scope.share = function (item) {
    alert('Share Item: ' + item.id);
  };

  $scope.moveItem = function (item, fromIndex, toIndex) {
    $scope.notifications.splice(fromIndex, 1);
    $scope.notifications.splice(toIndex, 0, item);
  };

  $scope.onItemDelete = function (item) {
    $scope.notifications.splice($scope.notifications.indexOf(item), 1);
  };

  $scope.notifications = [{
    id: 1,
    user: 'Janice Burke',
    text: 'Lorem ipsum dolor sit amet, per veri petentium iudicabit in.',
    img: '1.jpg'
  }, {
    id: 2,
    user: 'Raymond Powell',
    text: 'Per tale expetendis signiferumque eu, mea partem causae vocent id.',
    img: '2.jpg'
  }, {
    id: 3,
    user: 'Danielle Beck',
    text: 'Velit malorum eos ne, his ut probo possit contentiones.',
    img: '3.jpg'
  }, {
    id: 4,
    user: 'Ronald Hall',
    text: 'Posse petentium imperdiet nec ex, ea sed detraxit molestiae.',
    img: '4.jpg'
  }, {
    id: 5,
    user: 'Catherine Hunt',
    text: 'Semper urbanitas ullamcorper ut eam. Sint summo consequuntur ad nam, vix cu mucius alienum detracto, et eum zril labores abhorreant.',
    img: '5.jpg'
  }]


})

app.controller('UserCtrl', function ($scope, $rootScope, $state, $ionicLoading, $ionicSideMenuDelegate, $firebaseObject, $firebaseAuth) {

  $ionicSideMenuDelegate.canDragContent(false);

  $scope.start = function () {
    $state.go('app.home');
  };

  $scope.authObj = $firebaseAuth();


  // firebase register
  $scope.register = function (email, password, phone) {
    $scope.authObj.$createUserWithEmailAndPassword(email, password)
      .then(function (firebaseUser) {

        // create 'user' array same id - to store user profile
        var refArray = firebase.database().ref().child("users").child(firebaseUser.uid);
        var users = $firebaseObject(refArray);
        users.email = firebaseUser.email;
        users.phone = phone;
        users.$save().then(function (ref) {

        }, function (error) {
          console.log("Error:", error);
        });

        alert('User created! You are signed in.');
        $state.go('app.home');
      }).catch(function (error) {
        console.error("Error: ", error);
      });
  };


  // firebase login
  $scope.login = function (email, password) {
    $scope.authObj.$signInWithEmailAndPassword(email, password).then(function (firebaseUser) {
      //alert("Signed in!");
      $scope.getUserStatus();
      console.log($rootScope.user);
      // redirect to home screen
      $state.go('app.home');
    }).catch(function (error) {
      console.error("Authentication failed:", error);
    });
  }


  // reset password
  $scope.reset = function (email) {
    $scope.authObj.$sendPasswordResetEmail(email).then(function () {
      alert("Password reset email sent successfully!");
      $state.go('app.login');
    }).catch(function (error) {
      console.error("Error: ", error);
    });

  }



})

app.controller('NewsCtrl', function ($scope, $ionicLoading, FeedSources, FeedList) {

  $ionicLoading.show({
    template: 'Loading news...'
  });

  // NEWS SOURCES - from services
  $scope.categories = FeedSources;

  $ionicLoading.hide();

});

app.controller('NewslistCtrl', function ($http, $scope, $state, $ionicLoading,  $stateParams, $ionicModal, FeedSources, FeedList) {

  $scope.posts = [];
  var wordpressUrl = "https://api.rss2json.com/v1/api.json?rss_url=https%3A%2F%2Fseacoast.citymomsblog.com%2Ffeed%2F&api_key=4ttyqm0kfrvec25ygfqnw27nmdmqc4gkieabiii2&order_by=&order_dir=desc&count=20";

    $http.get(wordpressUrl)
      .success(function(response){
        angular.forEach(response.items, function(child){
          $scope.posts.push(child);
        });
      })
      .error(function(response, status){
        console.log("Error while received response. " + status + response);
      });

      $scope.openUrl = function(link) {
          window.open(link, '_blank', 'location=yes');
          return false;
        }


})

app.controller('HomeCtrl', function ($scope, $ionicLoading, $ionicSideMenuDelegate, $ionicScrollDelegate) {

  $ionicSideMenuDelegate.canDragContent(true);


  // TABS
  $scope.tab = 1;
  $scope.activeMenu = 1;

  $scope.setTab = function (newTab) {
    $scope.tab = newTab;
    $scope.activeMenu = newTab;
  };

  $scope.isSet = function (tabNum) {
    return $scope.tab === tabNum;
  };


  // ACCORDIONS
  // initiate an array to hold all active tabs
  $scope.activeTabs = [];

  // check if the tab is active
  $scope.isOpenTab = function (tab) {
    // check if this tab is already in the activeTabs array
    if ($scope.activeTabs.indexOf(tab) > -1) {
      // if so, return true
      return true;
    } else {
      // if not, return false
      return false;
    }
  }

  // function to 'open' a tab
  $scope.openTab = function (tab) {
    // check if tab is already open
    if ($scope.isOpenTab(tab)) {
      //if it is, remove it from the activeTabs array
      $scope.activeTabs.splice($scope.activeTabs.indexOf(tab), 1);
    } else {
      // if it's not, add it!
      $scope.activeTabs = [];
      $scope.activeTabs.push(tab);
    }
  }


})




app.controller('BlogCtrl', function ($scope, $ionicLoading, $stateParams, Blog, $cordovaSocialSharing) {

  $ionicLoading.show({
    template: 'Loading posts...'
  });


  $scope.categShow = false;
  $scope.showCategories = function () {
    if ($scope.categShow == false) {
      $scope.categShow = true;
    } else {
      $scope.categShow = false;
    }
  }


  // WORDPRESS CATEGORIES
  Blog.categories().then(
    function (data) {
      $scope.categories = data.data.categories;
      $ionicLoading.hide();
    },
    function (error) {
    }
  )




  // WORDPRESS POSTS
  $scope.getPosts = function () {
    Blog.posts($stateParams.id).then(
      function (data) {
        $scope.posts = data.data.posts;
        $ionicLoading.hide();
      },
      function (error) {
      }
    )
  }


  // WORDPRESS SINGLE POST
  $scope.getPost = function () {
    Blog.post($stateParams.id).then(
      function (data) {
        $scope.post = firebase(ref.userInfo(id));
        $ionicLoading.hide();
      },
      function (error) {
      }
    )
  }


  // SHARE
  $scope.shareTwitter = function (message, image) {
    $cordovaSocialSharing
      .shareViaTwitter(message, image, 'linkhere')
      .then(function (result) {
        // Success!
      }, function (err) {
        // An error occurred. Show a message to the user
      });
  }
  $scope.shareFacebook = function (message, image) {
    $cordovaSocialSharing
      .shareViaFacebook(message, image, 'link')
      .then(function (result) {
        // Success!
      }, function (err) {
        // An error occurred. Show a message to the user
      });
  }
  $scope.shareWhatsApp = function (message, image) {
    $cordovaSocialSharing
      .shareViaWhatsApp(message, image, 'link')
      .then(function (result) {
        // Success!
      }, function (err) {
        // An error occurred. Show a message to the user
      });
  }




})

var gLink = "";

app.controller('FirebaseCtrl', function ($scope, $ionicLoading, $filter, $ionicSlideBoxDelegate, Firebase, $firebaseObject, $firebaseArray, $stateParams, $sce) {

  $ionicLoading.show({
    template: 'Loading Firebase data...'
  });

  // FIREBASE
// $scope.body = $sce.trustAsHtml(htmlBody);

$scope.trustedHtml = function (plainText) {
            return $sce.trustAsHtml(plainText);
        };

  $scope.articleID = $stateParams.id;
  $scope.selectedArticle = {};
  // object
  var URL = Firebase.url();

  /*var refObject = firebase.database().ref().child("data"); // work with firebase url + object named 'data'
  // download the data into a local object
  var syncObject = $firebaseObject(refObject);
  // synchronize the object with a three-way data binding
  syncObject.$bindTo($scope, "firebaseObject"); // $scope.firebaseObject is your data from Firebase - you can edit/save/remove
  */
  $ionicLoading.hide();

  //to sanitize html
  $scope.sanitizeMe = function (text) {
    return $sce.trustAsHtml(text)
  };

  // array
  var refArrayMessages = firebase.database().ref().child("messages");
  // create a synchronized array
  $scope.messages = $firebaseArray(refArrayMessages); // $scope.messages is your firebase array, you can add/remove/edit
  // add new items to the array
  // the message is automatically added to our Firebase database!
  $scope.addMessage = function (message) {
    $scope.newMessageText = null;
    $scope.messages.$add({
      text: message
    });

  };

  String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
  };
  // array
  var refArray = firebase.database().ref().child("userInfo");
  // create a synchronized array
  var articleListRef = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit

  // add new items to the array
  // the message is automatically added to our Firebase database!
  articleListRef.$loaded()
    .then(function (x) {
      $scope.articles = x;
      if ($scope.articleID) {
        $scope.articles.forEach(function (d, i) {
          if (d.$id == $scope.articleID) {
            $scope.selectedArticle = d;
            var body = d.body;
            var tempBody = d.body;
            // body = body.replaceAll('href.*"', "");
            // gLink = tempBody.match(/href="([^"]*)/)[1];
            // body = body.replace("<a", "<label");
            // body = body.replace("</a>", "</label>");
            $scope.selectedArticle.body = body;
            console.log(gLink);
            //$scope.selectedArticle.body = "<a href='http://www.google.com' target='_blank'>Post</a>";
          }
        })
      }
    })
    .catch(function (error) {
      console.log("Error:", error);
    });

  $scope.addMessage = function (message) {
    $scope.newMessageText = null;
    $scope.articles.$add({
      text: message
    });
  };

  // $(document).on('click', function (evt) {
  //   if ($(evt.target).is('label')) {
  //     var ref = cordova.InAppBrowser.open(gLink, '_blank');
  //   }
  // });

})


app.controller('ElementsCtrl', function ($scope) {

})


app.controller('PluginsCtrl', function ($scope, $ionicLoading, $ionicPlatform, $cordovaToast, $cordovaAppRate, $cordovaBarcodeScanner, $cordovaDevice) {




  // toast message
  $scope.showToast = function () {
    $ionicPlatform.ready(function () {
      $cordovaToast.showLongBottom('Here is a toast message').then(function (success) {
        // success
      }, function (error) {
        // error
      });
    })
  }




  // rate my app
  $scope.showApprate = function () {

    $ionicPlatform.ready(function () {

      $cordovaAppRate.promptForRating(true).then(function (result) {
        // success
      });

    })

  }



  // barcode scanner
  $scope.showBarcode = function () {

    $ionicPlatform.ready(function () {

      $cordovaBarcodeScanner
        .scan()
        .then(function (barcodeData) {
          // Success! Barcode data is here
          alert(barcodeData.text);
          console.log("Barcode Format -> " + barcodeData.format);
          console.log("Cancelled -> " + barcodeData.cancelled);
        }, function (error) {
          // An error occurred
          console.log("An error happened -> " + error);
        });

    })

  }




  // device info
  $scope.showDeviceinfo = function () {

    $ionicPlatform.ready(function () {

      var device = $cordovaDevice.getDevice();
      var cordova = $cordovaDevice.getCordova();
      var model = $cordovaDevice.getModel();
      var platform = $cordovaDevice.getPlatform();
      var uuid = $cordovaDevice.getUUID();
      var version = $cordovaDevice.getVersion();

      alert('Your device has ' + platform);

    })

  }

  $ionicSideMenuDelegate.canDragContent(true);


  // TABS
  $scope.tab = 1;
  $scope.activeMenu = 1;

  $scope.setTab = function (newTab) {
    $scope.tab = newTab;
    $scope.activeMenu = newTab;
  };

  $scope.isSet = function (tabNum) {
    return $scope.tab === tabNum;
  };


  // ACCORDIONS
  // initiate an array to hold all active tabs
  $scope.activeTabs = [];

  // check if the tab is active
  $scope.isOpenTab = function (tab) {
    // check if this tab is already in the activeTabs array
    if ($scope.activeTabs.indexOf(tab) > -1) {
      // if so, return true
      return true;
    } else {
      // if not, return false
      return false;
    }
  }

  // function to 'open' a tab
  $scope.openTab = function (tab) {
    // check if tab is already open
    if ($scope.isOpenTab(tab)) {
      //if it is, remove it from the activeTabs array
      $scope.activeTabs.splice($scope.activeTabs.indexOf(tab), 1);
    } else {
      // if it's not, add it!
      $scope.activeTabs = [];
      $scope.activeTabs.push(tab);
    }
  }


});


// rate my app preferences
app.config(function ($cordovaAppRateProvider) {

  document.addEventListener("deviceready", function () {

    var prefs = {
      language: 'en',
      appName: 'SBFC',
      iosURL: '<my_app_id>',
      androidURL: 'market://details?id=<package_name>',
      windowsURL: 'ms-windows-store:Review?name=<...>'
    };

    $cordovaAppRateProvider.setPreferences(prefs)

  }, false);

})

app.controller('ChatCtrl', function ($scope, $rootScope, $state, $timeout, $ionicLoading, $firebaseAuth, $firebaseArray, FirebaseUser, ngQuillConfig) {

  $scope.getUserStatus();

  $scope.user = {
    published: '',
    publish_date: new Date(),
    title: ''
  }

  /* datepicker */
  $scope.valuationDate = new Date();
  $scope.valuationDatePickerIsOpen = false;

  $scope.valuationDatePickerOpen = function () {

    $scope.valuationDatePickerIsOpen = true;
  };

  var pdfDoc = angular.element(document.querySelector('#fileInput'));



  /* /datepicker */

  $scope.message = '';

  var downloadUrl = '';

  $scope.showToolbar = true;

  $scope.categoryDropDown = {
    selected: null,
    categoryOptions: [
      { id: 0, name: 'No Category', value: '' },
      { id: 1, name: 'Ask an Expert', value: 'ask-an-expert' },
      { id: 2, name: 'Marketplace', value: 'marketplace' },
      { id: 3, name: 'Baby Photo', value: 'baby-photo' }
    ]
  };

  /*$scope.translations = angular.extend({}, ngQuillConfig.translations, {
   15: 'smallest'
   });*/

  /*$scope.toggle = function() {
   $scope.showToolbar = !$scope.showToolbar;
   };*/
  // Own callback after Editor-Creation
  /*$scope.editorCallback = function (editor, name) {
   console.log('createCallback', editor, name);
   };*/

  $scope.readOnly = false;

  $scope.isReadonly = function () {
    return $scope.readOnly;
  };

  $scope.clear = function () {
    return $scope.message = '';
  };

  // Event after an editor is created --> gets the editor instance on optional the editor name if set
  $scope.$on('editorCreated', function (event, editor, name) {
    console.log('createEvent', editor, name);
  });

  $timeout(function () {
    $scope.message = '';
    console.log($scope.message);
  }, 3000);
  $scope.getMessages = function () {

    //$scope.version = textAngularManager.getVersion();
    //$scope.versionNumber = $scope.version.substring(1);
    /*$scope.orightml = '<h2>Try me!</h2><p>textAngular is a super cool WYSIWYG Text Editor directive for AngularJS</p><p><img class="ta-insert-video" ta-insert-video="http://www.youtube.com/embed/2maA1-mvicY" src="" allowfullscreen="true" width="300" frameborder="0" height="250"/></p><p><b>Features:</b></p><ol><li>Automatic Seamless Two-Way-Binding</li><li>Super Easy <b>Theming</b> Options</li><li style="color: green;">Simple Editor Instance Creation</li><li>Safely Parses Html for Custom Toolbar Icons</li><li class="text-danger">Doesn&apos;t Use an iFrame</li><li>Works with Firefox, Chrome, and IE9+</li></ol><p><b>Code at GitHub:</b> <a href="https://github.com/fraywing/textAngular">Here</a> </p><h4>Supports non-latin Characters</h4><p>昮朐 魡 燚璒瘭 譾躒鑅, 皾籈譧 紵脭脧 逯郹酟 煃 瑐瑍, 踆跾踄 趡趛踠 顣飁 廞 熥獘 豥 蔰蝯蝺 廦廥彋 蕍蕧螛 溹溦 幨懅憴 妎岓岕 緁, 滍 蘹蠮 蟷蠉蟼 鱐鱍鱕, 阰刲 鞮鞢騉 烳牼翐 魡 骱 銇韎餀 媓幁惁 嵉愊惵 蛶觢, 犝獫 嶵嶯幯 縓罃蔾 魵 踄 罃蔾 獿譿躐 峷敊浭, 媓幁 黐曮禷 椵楘溍 輗 漀 摲摓 墐墆墏 捃挸栚 蛣袹跜, 岓岕 溿 斶檎檦 匢奾灱 逜郰傃</p>';
     $scope.htmlcontent = $scope.orightml;*/
    //$scope.disabled = false;


    $timeout(function () {
      // set firebase refference for messages - if user is logged in, set to match user uid, if there is no user, show public messages
      var refArray = firebase.database().ref().child("chat/" + $rootScope.userUid);
      // create a synchronized array
      $scope.messages = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
    }, 100)
  };

  $scope.getMessages();

  // send message
  $scope.send = function (message) {

    $scope.getMessages();

    // set a random image as user avatar - change this to match your structure
    var randomIndex = Math.round(Math.random() * (4));
    randomIndex++;
    $scope.avatar = 'img/users/' + randomIndex + '.jpg';
    // add new items to the array
    // the message is automatically added to our Firebase database!
    $scope.messages.$add({
      text: message,
      email: $rootScope.user,
      user: $rootScope.userUid,
      avatar: $scope.avatar
    });
    $scope.message = '';
  };

  $scope.storeImageToDB = function (file, resolve) {

    /*var file = document.querySelector('input[type=file]').files[0];
     console.log(file);*/
    var storageRef = firebase.storage().ref().child('images');
    // Get a reference to store file at photos/<FILENAME>.jpg
    var photoRef = storageRef.child(file.name);
    // Upload file to Firebase Storage
    var uploadTask = photoRef.putString(file.base64, 'data_url');
    uploadTask.on('state_changed', null, null, function (snapshot) {
      console.log('success');
      console.log(snapshot);
      // When the image has successfully uploaded, we get its download URL
      downloadUrl = uploadTask.snapshot.downloadURL;
      console.log(downloadUrl);
      resolve(downloadUrl);
      // Set the download URL to the message box, so that the user can send it to the database
      //$scope.userDisplayPic = downloadUrl;
    });
  };
  $scope.storePDFDocToDB = function (file, resolve) {

    /*var file = document.querySelector('input[type=file]').files[0];
     console.log(file);*/
    var storageRef = firebase.storage().ref().child('pdf');
    // Get a reference to store file at photos/<FILENAME>.jpg
    var photoRef = storageRef.child(file.name);
    // Upload file to Firebase Storage
    var uploadTask = photoRef.put(file);
    uploadTask.on('state_changed', null, null, function (snapshot) {
      console.log('success');
      console.log(snapshot);
      // When the image has successfully uploaded, we get its download URL
      downloadUrl = uploadTask.snapshot.downloadURL;
      console.log(downloadUrl);
      resolve(downloadUrl);
      // Set the download URL to the message box, so that the user can send it to the database
      //$scope.userDisplayPic = downloadUrl;
    });
  };

  // function extractLinkFromBody(text) {
  //   var urlRegex = /(https?:\/\/[^\s]+)/g;
  //   return text.replace(urlRegex, function (url) {
  //     var indexOfATag = url.indexOf('<');
  //     var slicedUrl = url.slice(0, indexOfATag);
  //     /*console.log(slicedUrl)
  //      return '<a href="' + slicedUrl + '">' + slicedUrl + '</a>'; */
  //     return '<a href="' + slicedUrl + '" onClick="window.open("' + slicedUrl + '");return false;">' + slicedUrl + '</a>';
  //   });
  //   // or alternatively
  //   // return text.replace(urlRegex, '<a href="$1">$1</a>')
  // }
  $scope.saveData = function (user, msg, b64) {
    var pdfIsTrue = false;
    var userData = {};
    userData = $scope.user;
    // userData.body = extractLinkFromBody(userData.body)
    console.log(user, msg);
    userData.body = msg;
    userData.publish_date = new Date(userData.publish_date).getTime();
    userData.author = $rootScope.user;
    userData.category = $scope.categoryDropDown.selected;

    imgObj.base64 = b64;
    pdfDoc = pdfDoc[0].files[0];
    if (pdfDoc) {
      if (pdfDoc.name.indexOf('pdf') > -1) {
        pdfIsTrue = true;
      }
    }
    console.log(pdfDoc);

    var uploadPromiseImgs = new Promise(function (resolve, reject) {
      if (pdfIsTrue) {
        $scope.storePDFDocToDB(pdfDoc, resolve);
      } else {
        $scope.storeImageToDB(imgObj, resolve);
      }
    });
    Promise.all([uploadPromiseImgs]).then(function (data) {
      userData.img = downloadUrl;
      var ref = firebase.database().ref().child("userInfo");
      var userNode = $firebaseArray(ref);
      userNode.$add(userData).then(function (success) {
        var addedObjDetails = success.path.o;
        var addedObj = addedObjDetails[1];
        $state.go('app.edit', { 'id': addedObj })
        console.log(success);
        console.log(addedObj[1]);
      });
    }).catch(function (err) {
      console.log(err);
    })
  };
  var imgObj = {};
  $scope.myImage = '';
  $scope.myCroppedImage = '';

  var handleFileSelect = function (evt) {
    var file = evt.currentTarget.files[0];
    imgObj.name = file.name;
    var reader = new FileReader();
    reader.onload = function (evt) {
      $scope.$apply(function ($scope) {
        $scope.myImage = evt.target.result;
      });
    };
    reader.readAsDataURL(file);
  };
  angular.element(document.querySelector('#fileInput')).on('change', handleFileSelect);

})


app.controller('EditCtrl', function ($scope, $rootScope, $state, $stateParams, $timeout, $ionicLoading, $firebaseAuth, $firebaseObject, $firebaseArray, FirebaseUser, ngQuillConfig, ionicToast, $cordovaInAppBrowser) {


  $scope.articleID = $stateParams.id;
  $scope.getUserStatus();

  $scope.user = {
    published: '',
    publish_date: new Date(),
    title: ''
  }

  // array
  var refArray = firebase.database().ref().child("userInfo").child($scope.articleID);
  // create a synchronized array
  var articleListRef = $firebaseObject(refArray); // $scope.messages is your firebase array, you can add/remove/edit
  // add new items to the array
  // the message is automatically added to our Firebase database!
  articleListRef.$loaded()
    .then(function (x) {
      $scope.user = x;
      $scope.categoryDropDown.selected = $scope.user.category;
      $scope.user.publish_date = new Date($scope.user.publish_date);
      $scope.message = $scope.user.body;
      ngQuillConfig.setHTML($scope.user.body);
    })
    .catch(function (error) {
      console.log("Error:", error);
    });

  $scope.$on("editorCreated", function (event, quillEditor) {
    quillEditor.setHTML($scope.user.body);
  });

  /* datepicker */
  $scope.valuationDate = new Date();
  $scope.valuationDatePickerIsOpen = false;

  $scope.valuationDatePickerOpen = function () {

    $scope.valuationDatePickerIsOpen = true;
  };

  /* /datepicker */

  $scope.message = 'Your Body Text ';

  var downloadUrl = '';

  $scope.showToolbar = true;

  $scope.categoryDropDown = {
    selected: null,
    categoryOptions: [
      { id: 0, name: 'No Category', value: '' },
      { id: 1, name: 'Ask an Expert', value: 'ask-an-expert' },
      { id: 2, name: 'Marketplace', value: 'marketplace' },
      { id: 3, name: 'Baby Photo', value: 'baby-photo' }
    ]
  };

  $scope.showToast = function () {
    <!--ionicToast.show(message, position, stick, time); -->
      ionicToast.show('This is a toast at the top.', 'top', false, 2500);
  };

  $scope.hideToast = function () {
    ionicToast.hide();
  };

  /*$scope.translations = angular.extend({}, ngQuillConfig.translations, {
   15: 'smallest'
   });*/

  /*$scope.toggle = function() {
   $scope.showToolbar = !$scope.showToolbar;
   };*/
  // Own callback after Editor-Creation
  /*$scope.editorCallback = function (editor, name) {
   console.log('createCallback', editor, name);
   };*/


  $scope.readOnly = false;

  $scope.isReadonly = function () {
    return $scope.readOnly;
  };

  $scope.clear = function () {
    return $scope.message = '';
  };

  $scope.getMessages = function () {

    //$scope.version = textAngularManager.getVersion();
    //$scope.versionNumber = $scope.version.substring(1);
    /*$scope.orightml = '<h2>Try me!</h2><p>textAngular is a super cool WYSIWYG Text Editor directive for AngularJS</p><p><img class="ta-insert-video" ta-insert-video="http://www.youtube.com/embed/2maA1-mvicY" src="" allowfullscreen="true" width="300" frameborder="0" height="250"/></p><p><b>Features:</b></p><ol><li>Automatic Seamless Two-Way-Binding</li><li>Super Easy <b>Theming</b> Options</li><li style="color: green;">Simple Editor Instance Creation</li><li>Safely Parses Html for Custom Toolbar Icons</li><li class="text-danger">Doesn&apos;t Use an iFrame</li><li>Works with Firefox, Chrome, and IE9+</li></ol><p><b>Code at GitHub:</b> <a href="https://github.com/fraywing/textAngular">Here</a> </p><h4>Supports non-latin Characters</h4><p>昮朐 魡 燚璒瘭 譾躒鑅, 皾籈譧 紵脭脧 逯郹酟 煃 瑐瑍, 踆跾踄 趡趛踠 顣飁 廞 熥獘 豥 蔰蝯蝺 廦廥彋 蕍蕧螛 溹溦 幨懅憴 妎岓岕 緁, 滍 蘹蠮 蟷蠉蟼 鱐鱍鱕, 阰刲 鞮鞢騉 烳牼翐 魡 骱 銇韎餀 媓幁惁 嵉愊惵 蛶觢, 犝獫 嶵嶯幯 縓罃蔾 魵 踄 罃蔾 獿譿躐 峷敊浭, 媓幁 黐曮禷 椵楘溍 輗 漀 摲摓 墐墆墏 捃挸栚 蛣袹跜, 岓岕 溿 斶檎檦 匢奾灱 逜郰傃</p>';
     $scope.htmlcontent = $scope.orightml;*/
    //$scope.disabled = false;


    $timeout(function () {
      // set firebase refference for messages - if user is logged in, set to match user uid, if there is no user, show public messages
      var refArray = firebase.database().ref().child("chat/" + $rootScope.userUid);
      // create a synchronized array
      $scope.messages = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
    }, 100)
  };

  $scope.getMessages();

  // send message
  $scope.send = function (message) {

    $scope.getMessages();

    // set a random image as user avatar - change this to match your structure
    var randomIndex = Math.round(Math.random() * (4));
    randomIndex++;
    $scope.avatar = 'img/users/' + randomIndex + '.jpg';
    // add new items to the array
    // the message is automatically added to our Firebase database!
    $scope.messages.$add({
      text: message,
      email: $rootScope.user,
      user: $rootScope.userUid,
      avatar: $scope.avatar
    });
    $scope.message = '';
  };

  $scope.storeImageToDB = function (file, resolve) {

    /*var file = document.querySelector('input[type=file]').files[0];
     console.log(file);*/
    var storageRef = firebase.storage().ref().child('images');
    // Get a reference to store file at photos/<FILENAME>.jpg
    var photoRef = storageRef.child(file.name);
    // Upload file to Firebase Storage
    var uploadTask = photoRef.putString(file.base64, 'data_url');
    uploadTask.on('state_changed', null, null, function (snapshot) {
      console.log('success');
      console.log(snapshot);
      // When the image has successfully uploaded, we get its download URL
      downloadUrl = uploadTask.snapshot.downloadURL;
      console.log(downloadUrl);
      resolve(downloadUrl);
      // Set the download URL to the message box, so that the user can send it to the database
      //$scope.userDisplayPic = downloadUrl;
    });
  };

  // function extractLinkFromBody(text) {
  //   var urlRegex = /(https?:\/\/[^\s]+)/g;
  //   return text.replace(urlRegex, function (url) {
  //     var indexOfATag = url.indexOf('<');
  //     var slicedUrl = url.slice(0, indexOfATag);
  //     /*console.log(slicedUrl)
  //     return '<a href="' + slicedUrl + '">' + slicedUrl + '</a>'; */
  //     return '<a href="' + slicedUrl + '" onClick="window.open("' + slicedUrl + '");return false;">' + slicedUrl + '</a>';
  //   });
  //   // or alternatively
  //   // return text.replace(urlRegex, '<a href="$1">$1</a>')
  // }
  var optionsForInApp = {
    location: 'yes',
    clearcache: 'yes',
    toolbar: 'yes',
    closebuttoncaption: 'DONE?'
  };
  function openlink(url) {
    /*$cordovaInAppBrowser.open(url, '_blank', optionsForInApp)
      .then(function(event) {
        // success
      })
      .catch(function(event) {
        // error
      });*/
    console.log('lala kaka');
  };

  $scope.saveData = function (user, msg, b64) {
    var userData = {};
    userData = $scope.user;
    // if (userData.body.indexOf('<a>') == -1) {
    //   userData.body = extractLinkFromBody(userData.body);
    // }
    console.log(user, msg);
    //userData.body = msg;
    userData.publish_date = new Date(userData.publish_date).getTime();
    userData.author = $rootScope.user;
    userData.category = $scope.categoryDropDown.selected;
    articleListRef = userData;
    imgObj.base64 = b64;
    articleListRef.$save().then(function (ref) {
      // true
      ionicToast.show('Success!.', 'bottom', false, 2500);
      console.log('Successfully updates the object', ref);
    }, function (error) {
      console.log("Error:", error);
    });


    /*var uploadPromiseImgs = new Promise(function(resolve, reject) {
      $scope.storeImageToDB(imgObj,resolve);
    });
    Promise.all([uploadPromiseImgs]).then(function (data) {
      userData.img = downloadUrl;
      var ref = firebase.database().ref().child("userInfo");
      var userNode = $firebaseArray(ref);
      userNode.$add(userData).then(function (success) {
        console.log(success);
      });
    }).catch(function (err) {
      console.log(err);
    })*/
  };
  $scope.deleteEdited = function () {
    articleListRef.$remove().then(function (ref) {
      console.log("Successfully removed the Object:", ref);
      $state.go('app.allcontent')
    }, function (error) {
      console.log("Error:", error);
    });
  }
  var imgObj = {};
  $scope.myImage = '';
  $scope.myCroppedImage = '';

  var handleFileSelect = function (evt) {
    var file = evt.currentTarget.files[0];
    imgObj.name = file.name;
    var reader = new FileReader();
    reader.onload = function (evt) {
      $scope.$apply(function ($scope) {
        $scope.myImage = evt.target.result;
      });
    };
    reader.readAsDataURL(file);
  };
  angular.element(document.querySelector('#fileInput')).on('change', handleFileSelect);

})

app.controller('FileTransferCtrl', function ($scope, $rootScope, $state, $stateParams, $timeout, $ionicLoading, $firebaseAuth, $firebaseObject, $firebaseArray, FirebaseUser, ngQuillConfig, ionicToast, $cordovaInAppBrowser) {


  // array
  var refArray = firebase.database().ref().child("folder");
  // create a synchronized array
  var articleListRef = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
  // add new items to the array
  // the message is automatically added to our Firebase database!
  articleListRef.$loaded()
    .then(function (alluser) {
      $scope.usersFroFileTransfer = alluser;
    })
    .catch(function (error) {
      console.log("Error:", error);
    });


})

app.controller('AddFolderCtrl', function ($scope, $stateParams, $rootScope, $state, $timeout, $ionicLoading, $firebaseAuth, $firebaseArray, FirebaseUser, ngQuillConfig, $q, $firebaseObject, ionicToast) {

  $scope.getUserStatus();

  $scope.user = {
    published: '',
    publish_date: new Date(),
    title: ''
  }

  /* datepicker */
  $scope.valuationDate = new Date();
  $scope.valuationDatePickerIsOpen = false;

  $scope.valuationDatePickerOpen = function () {

    $scope.valuationDatePickerIsOpen = true;
  };

  var pdfDoc = angular.element(document.querySelector('#fileInput'));

  var folderRef = firebase.database().ref().child("folder");


  /* /datepicker */

  $scope.message = '';

  var downloadUrl = '';
  var downloadUrlArray = [];
  var thumbnailImage;
  var file;
  $scope.folderArray = [];

  $scope.showToolbar = true;

  $scope.categoryDropDown = {
    selected: null,
    categoryOptions: [
      { id: 0, name: 'No Category', value: '' },
      { id: 1, name: 'Ask an Expert', value: 'ask-an-expert' },
      { id: 2, name: 'Marketplace', value: 'marketplace' },
      { id: 3, name: 'Baby Photo', value: 'baby-photo' }
    ]
  };

  /*$scope.translations = angular.extend({}, ngQuillConfig.translations, {
   15: 'smallest'
   });*/

  /*$scope.toggle = function() {
   $scope.showToolbar = !$scope.showToolbar;
   };*/
  // Own callback after Editor-Creation
  /*$scope.editorCallback = function (editor, name) {
   console.log('createCallback', editor, name);
   };*/

  $scope.readOnly = false;

  $scope.isReadonly = function () {
    return $scope.readOnly;
  };

  $scope.clear = function () {
    return $scope.message = '';
  };

  // Event after an editor is created --> gets the editor instance on optional the editor name if set
  $scope.$on('editorCreated', function (event, editor, name) {
    console.log('createEvent', editor, name);
  });

  $timeout(function () {
    $scope.message = '';
    console.log($scope.message);
  }, 3000);
  $scope.getMessages = function () {

    //$scope.version = textAngularManager.getVersion();
    //$scope.versionNumber = $scope.version.substring(1);
    /*$scope.orightml = '<h2>Try me!</h2><p>textAngular is a super cool WYSIWYG Text Editor directive for AngularJS</p><p><img class="ta-insert-video" ta-insert-video="http://www.youtube.com/embed/2maA1-mvicY" src="" allowfullscreen="true" width="300" frameborder="0" height="250"/></p><p><b>Features:</b></p><ol><li>Automatic Seamless Two-Way-Binding</li><li>Super Easy <b>Theming</b> Options</li><li style="color: green;">Simple Editor Instance Creation</li><li>Safely Parses Html for Custom Toolbar Icons</li><li class="text-danger">Doesn&apos;t Use an iFrame</li><li>Works with Firefox, Chrome, and IE9+</li></ol><p><b>Code at GitHub:</b> <a href="https://github.com/fraywing/textAngular">Here</a> </p><h4>Supports non-latin Characters</h4><p>昮朐 魡 燚璒瘭 譾躒鑅, 皾籈譧 紵脭脧 逯郹酟 煃 瑐瑍, 踆跾踄 趡趛踠 顣飁 廞 熥獘 豥 蔰蝯蝺 廦廥彋 蕍蕧螛 溹溦 幨懅憴 妎岓岕 緁, 滍 蘹蠮 蟷蠉蟼 鱐鱍鱕, 阰刲 鞮鞢騉 烳牼翐 魡 骱 銇韎餀 媓幁惁 嵉愊惵 蛶觢, 犝獫 嶵嶯幯 縓罃蔾 魵 踄 罃蔾 獿譿躐 峷敊浭, 媓幁 黐曮禷 椵楘溍 輗 漀 摲摓 墐墆墏 捃挸栚 蛣袹跜, 岓岕 溿 斶檎檦 匢奾灱 逜郰傃</p>';
     $scope.htmlcontent = $scope.orightml;*/
    //$scope.disabled = false;


    $timeout(function () {
      // set firebase refference for messages - if user is logged in, set to match user uid, if there is no user, show public messages
      var refArray = firebase.database().ref().child("chat/" + $rootScope.userUid);
      // create a synchronized array
      $scope.messages = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
    }, 100)
  };

  //This will contain our files
  var data = Array();

  //Function to check whether or not this will work
  var supported = function () {

    //All of the stuff we need
    if (window.File && window.FileReader && window.FileList && window.Blob && window.XMLHttpRequest) {
      return true;
    } else {
      return false;
    }
  };

  //The Input File has Been Loaded Into Memory!
  var loaded = function (event) {
    //Push the data into our array
    //But don't start uploading just yet
    thumbnailImage = event.target.result;
    file.thumbnailImage = event.target.result;
    data.push(event.target.result);
  };

  var uploadFile = function (event) {
    //Needs a Better Way to
    //Link Data to Button
    var id = $(this).attr('data');
    $.ajax({
      type: "POST",
      //JSFiddle Echo Server
      url: "/echo/html/",

      data: {
        "html": "<li><a target=\"_blank\" href=\"" + data[id] + "\">link</a></li>"
      },
      success: function (data) {
        $("#ajax").append(data);
      },
      dataType: 'html'
    });
  };

  var processFiles = function (event) {

    //If not supported tell them to get a better browser
    if (!supported) {
      alert('upgrade your browser');
      return;
    }

    //Our iterator's up here? as specified by JSLint
    var i;

    //Get the FileList Object - http://goo.gl/AkgYa
    var files = event.target.files;

    //Loop through our files
    for (i = 0; i < files.length; i += 1) {

      //Just for Clarity Create a New Variable
      file = files[i];
      // $scope.folderFile = file;
      $scope.folderArray.push(file)

      //A New Reader for Each File
      var reader = new FileReader();
      //Done reading the file?.. Push the data to the data array
      reader.onload = loaded;

      // Read in the image file as base64
      // You could do it in binary or text - http://goo.gl/4hYSd
      reader.readAsDataURL(file);
      /*

                       //Make Upload Button
                       "<button class=\"upload\" data=\"",
                       i,
                       "\">Upload</button>",
                       //Get Size in Kilobytes
                       "<span>",
                       file.size / 1024,
                       " kb</span>",
      */

      //Build the File Info HTML
      var fileInfo = ["<li>",
        "<img src=\"" + thumbnailImage + "\" class='imgPreview'>",

        file.name,
        "</li>"].join('');

      //Add the Info to the list
      //$("#list").append(fileInfo);


    }
    //Add a Click Listener OUTSIDE of the loop
    $(".upload").on("click", uploadFile);
  };

  //When the Input Changes Reprocess Files
  $("#fileInput").on("change", processFiles);


  $scope.getMessages();

  // send message
  $scope.send = function (message) {

    $scope.getMessages();

    // set a random image as user avatar - change this to match your structure
    var randomIndex = Math.round(Math.random() * (4));
    randomIndex++;
    $scope.avatar = 'img/users/' + randomIndex + '.jpg';
    // add new items to the array
    // the message is automatically added to our Firebase database!
    $scope.messages.$add({
      text: message,
      email: $rootScope.user,
      user: $rootScope.userUid,
      avatar: $scope.avatar
    });
    $scope.message = '';
  };

  function storeFolderImages(file) {

    var innerDeferred = $q.defer();

    //storeFolderImages(myfile, resolve);
    var storageRef = firebase.storage().ref().child('folder').child('images').child(file.name);
    // Upload file to Firebase Storage
    delete file.thumbnailImage;
    var uploadTask = storageRef.put(file);
    uploadTask.on('state_changed', null, null, function () {
      var downloadUrl = uploadTask.snapshot.downloadURL;
      innerDeferred.resolve(downloadUrl);
    })
    // Set the download URL to the message box, so that the user can send it to the database
    //$scope.userDisplayPic = downloadUrl;
    return innerDeferred.promise;
  };
  $scope.saveFolder = function (folderInfo) {
    var deferred = $q.defer();
    console.log(folderInfo, $scope.folderArray)
    var uploadPromiseFolderImgs = $scope.folderArray.map(function (myfile, index) {
      var innerDeferred = $q.defer();

      //storeFolderImages(myfile, resolve);
      var storageRef = firebase.storage().ref().child('folder').child('images').child(myfile.name);
      // Upload file to Firebase Storage
      //delete myfile.thumbnailImage;
      var uploadTask = storageRef.putString(myfile.thumbnailImage, 'data_url');
      uploadTask.on('state_changed', null, null, function () {
        var downloadUrl = uploadTask.snapshot.downloadURL;
        innerDeferred.resolve(downloadUrl);
      })
      // Set the download URL to the message box, so that the user can send it to the database
      //$scope.userDisplayPic = downloadUrl;
      return innerDeferred.promise;
    })
    $q.all(uploadPromiseFolderImgs).then(function (imageResolved) {
      console.log(imageResolved);
      var imgArrNames = [];
      var imagesObj = {};
      var j = 0;
      for (var i = 0; i < imageResolved.length; ++i) {
        var imgArrNames = "image-" + i;
        var indexOfImgName = imgArrNames;
        var indexOfImgReslved = imageResolved[ j ];
        imagesObj[indexOfImgName] = indexOfImgReslved;
      }
      folderInfo.images = imagesObj;
      var folderNode = $firebaseArray(folderRef);
      folderNode.$add(folderInfo).then(function (success) {
        var addedObjectUid = success.path.o[1];
        ionicToast.show('Successfully added a folder!.', 'bottom', false, 2500);
        $state.go('app.editfolder', { 'id': addedObjectUid })
        console.log(success.path.o[1]);
      });
      deferred.resolve(imageResolved)
    }).catch(function (err) {
      console.log(err);
      deferred.reject(err);
    })
  }
  $scope.saveData = function (user, msg, b64) {
    var pdfIsTrue = false;
    var userData = {};
    userData = $scope.user;
    // userData.body = extractLinkFromBody(userData.body)
    console.log(user, msg);
    userData.body = message;
    userData.publish_date = new Date(userData.publish_date).getTime();
    userData.author = $rootScope.user;
    userData.category = $scope.categoryDropDown.selected;

    imgObj.base64 = b64;
    pdfDoc = pdfDoc[0].files[0];
    if (pdfDoc) {
      if (pdfDoc.name.indexOf('pdf') > -1) {
        pdfIsTrue = true;
      }
    }
    console.log(pdfDoc);

    var uploadPromiseImgs = new Promise(function (resolve, reject) {
      if (pdfIsTrue) {
        $scope.storePDFDocToDB(pdfDoc, resolve);
      } else {
        $scope.storeImageToDB(imgObj, resolve);
      }
    });
    Promise.all([uploadPromiseImgs]).then(function (data) {
      userData.img = downloadUrl;
      var ref = firebase.database().ref().child("userInfo");
      var userNode = $firebaseArray(ref);
      userNode.$add(userData).then(function (success) {
        var addedObjDetails = success.path.o;
        var addedObj = addedObjDetails[1];
        $state.go('app.edit', { 'id': addedObj })
        console.log(success);
        console.log(addedObj[1]);
      });
    }).catch(function (err) {
      console.log(err);
    })
  };
  var imgObj = {};
  $scope.myImage = '';
  $scope.myCroppedImage = '';

  var handleFileSelect = function (evt) {
    var file = evt.currentTarget.files[0];
    imgObj.name = file.name;
    var reader = new FileReader();
    reader.onload = function (evt) {
      $scope.$apply(function ($scope) {
        $scope.myImage = evt.target.result;
      });
    };
    reader.readAsDataURL(file);
  };
  angular.element(document.querySelector('#fileInput')).on('change', handleFileSelect);

})

app.controller('EditFolderCtrl', function ($scope, $stateParams, $rootScope, $state, $timeout, $ionicLoading, $firebaseAuth, $firebaseArray, FirebaseUser, ngQuillConfig, $q, $firebaseObject, ionicToast) {

  $scope.getUserStatus();
  $scope.editfolderArray = [];
  var uuid = $stateParams.id;
  if ($stateParams.id) {
    $scope.editFolderId = $stateParams.id;
    // array
    var refArray = firebase.database().ref().child("folder").child($scope.editFolderId);
    // create a synchronized array
    var editFolderRef = $firebaseObject(refArray); // $scope.messages is your firebase array, you can add/remove/edit
    // add new items to the array
    // the message is automatically added to our Firebase database!
    editFolderRef.$loaded()
      .then(function (folderData) {
        $scope.editFolder = folderData;
        for (var key in folderData.images) {
          $scope.editfolderArray.push(folderData.images[key]);
        }
      })
      .catch(function (error) {
        console.log("Error:", error);
      });
  }

  $scope.user = {
    published: '',
    publish_date: new Date(),
    title: ''
  }

  /* datepicker */
  $scope.valuationDate = new Date();
  $scope.valuationDatePickerIsOpen = false;

  $scope.valuationDatePickerOpen = function () {

    $scope.valuationDatePickerIsOpen = true;
  };

  var pdfDoc = angular.element(document.querySelector('#fileInput'));

  var folderRef = firebase.database().ref().child("folder");

  /* /datepicker */

  $scope.message = '';

  var downloadUrl = '';
  var downloadUrlArray = [];
  var thumbnailImage;
  var file;
  var uploadedFiles = [];
  $scope.folderArray = [];
  var newArrAfterRemovedImg = [];
  $scope.deleteImg = function (imgadd) {
    for (var key in editFolderRef.images) {
      if (editFolderRef.images[key] == imgadd) {
        delete editFolderRef.images[key]
        var indexOfToBeDeleteImg = $scope.editfolderArray.indexOf(imgadd);
        $scope.editfolderArray.splice(indexOfToBeDeleteImg,1);
        for (var key in editFolderRef.images) {
          newArrAfterRemovedImg.push(editFolderRef.images[key])
        }
        var imgArrNames = [];
        var imagesObj = {};
        for (var i = 0; i < newArrAfterRemovedImg.length; ++i) {
          imgArrNames[i] = "image-" + i;
          var indexOfImgName = imgArrNames[i];
          var indexOfImgReslved = newArrAfterRemovedImg[i];
          imagesObj[indexOfImgName] = indexOfImgReslved;
        }
        editFolderRef.images = imagesObj;
        //console.log('gotcha', editFolderRef)
      }
    }
  }


  $scope.showToolbar = true;

  $scope.categoryDropDown = {
    selected: null,
    categoryOptions: [
      { id: 0, name: 'No Category', value: '' },
      { id: 1, name: 'Ask an Expert', value: 'ask-an-expert' },
      { id: 2, name: 'Marketplace', value: 'marketplace' },
      { id: 3, name: 'Baby Photo', value: 'baby-photo' }
    ]
  };

  /*$scope.translations = angular.extend({}, ngQuillConfig.translations, {
   15: 'smallest'
   });*/

  /*$scope.toggle = function() {
   $scope.showToolbar = !$scope.showToolbar;
   };*/
  // Own callback after Editor-Creation
  /*$scope.editorCallback = function (editor, name) {
   console.log('createCallback', editor, name);
   };*/

  $scope.readOnly = false;

  $scope.isReadonly = function () {
    return $scope.readOnly;
  };

  $scope.clear = function () {
    return $scope.message = '';
  };

  // Event after an editor is created --> gets the editor instance on optional the editor name if set
  $scope.$on('editorCreated', function (event, editor, name) {
    console.log('createEvent', editor, name);
  });

  $timeout(function () {
    $scope.message = '';
    console.log($scope.message);
  }, 5000);
  $scope.getMessages = function () {

    //$scope.version = textAngularManager.getVersion();
    //$scope.versionNumber = $scope.version.substring(1);
    /*$scope.orightml = '<h2>Try me!</h2><p>textAngular is a super cool WYSIWYG Text Editor directive for AngularJS</p><p><img class="ta-insert-video" ta-insert-video="http://www.youtube.com/embed/2maA1-mvicY" src="" allowfullscreen="true" width="300" frameborder="0" height="250"/></p><p><b>Features:</b></p><ol><li>Automatic Seamless Two-Way-Binding</li><li>Super Easy <b>Theming</b> Options</li><li style="color: green;">Simple Editor Instance Creation</li><li>Safely Parses Html for Custom Toolbar Icons</li><li class="text-danger">Doesn&apos;t Use an iFrame</li><li>Works with Firefox, Chrome, and IE9+</li></ol><p><b>Code at GitHub:</b> <a href="https://github.com/fraywing/textAngular">Here</a> </p><h4>Supports non-latin Characters</h4><p>昮朐 魡 燚璒瘭 譾躒鑅, 皾籈譧 紵脭脧 逯郹酟 煃 瑐瑍, 踆跾踄 趡趛踠 顣飁 廞 熥獘 豥 蔰蝯蝺 廦廥彋 蕍蕧螛 溹溦 幨懅憴 妎岓岕 緁, 滍 蘹蠮 蟷蠉蟼 鱐鱍鱕, 阰刲 鞮鞢騉 烳牼翐 魡 骱 銇韎餀 媓幁惁 嵉愊惵 蛶觢, 犝獫 嶵嶯幯 縓罃蔾 魵 踄 罃蔾 獿譿躐 峷敊浭, 媓幁 黐曮禷 椵楘溍 輗 漀 摲摓 墐墆墏 捃挸栚 蛣袹跜, 岓岕 溿 斶檎檦 匢奾灱 逜郰傃</p>';
     $scope.htmlcontent = $scope.orightml;*/
    //$scope.disabled = false;


    $timeout(function () {
      // set firebase refference for messages - if user is logged in, set to match user uid, if there is no user, show public messages
      var refArray = firebase.database().ref().child("chat/" + $rootScope.userUid);
      // create a synchronized array
      $scope.messages = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
    }, 100)
  };

  //This will contain our files
  var data = Array();

  //Function to check whether or not this will work
  var supported = function () {

    //All of the stuff we need
    if (window.File && window.FileReader && window.FileList && window.Blob && window.XMLHttpRequest) {
      return true;
    } else {
      return false;
    }
  };

  //The Input File has Been Loaded Into Memory!
  var loaded = function (event) {
    //Push the data into our array
    //But don't start uploading just yet
    $scope.editfolderArray.push(event.target.result)
    thumbnailImage = event.target.result;
    file.thumbnailImage = event.target.result;
    data.push(event.target.result);
  };

  var uploadFile = function (event) {
    //Needs a Better Way to
    //Link Data to Button
    var id = $(this).attr('data');
    $.ajax({
      type: "POST",
      //JSFiddle Echo Server
      url: "/echo/html/",

      data: {
        "html": "<li><a target=\"_blank\" href=\"" + data[id] + "\">link</a></li>"
      },
      success: function (data) {
        $("#ajax").append(data);
      },
      dataType: 'html'
    });
  };

  var processFiles = function (event) {

    //If not supported tell them to get a better browser
    if (!supported) {
      alert('upgrade your browser');
      return;
    }

    //Our iterator's up here? as specified by JSLint
    var i;

    //Get the FileList Object - http://goo.gl/AkgYa
    var files = event.target.files;

    //Loop through our files
    for (i = 0; i < files.length; i += 1) {

      //Just for Clarity Create a New Variable
      file = files[i];
      // $scope.folderFile = file;
      $scope.folderArray.push(file)

      //A New Reader for Each File
      var reader = new FileReader();
      //Done reading the file?.. Push the data to the data array
      reader.onload = loaded;

      // Read in the image file as base64
      // You could do it in binary or text - http://goo.gl/4hYSd
      reader.readAsDataURL(file);
      /*

                       //Make Upload Button
                       "<button class=\"upload\" data=\"",
                       i,
                       "\">Upload</button>",
                       //Get Size in Kilobytes
                       "<span>",
                       file.size / 1024,
                       " kb</span>",
      */

      //Build the File Info HTML
      var fileInfo = ["<li>",
        "<img src=\"" + thumbnailImage + "\" class='imgPreview'>",

        file.name,
        "</li>"].join('');

      //Add the Info to the list
      //$("#list").append(fileInfo);


    }
    //Add a Click Listener OUTSIDE of the loop
    $(".upload").on("click", uploadFile);
  };

  //When the Input Changes Reprocess Files
  $("#fileInput").on("change", processFiles);


  $scope.getMessages();

  // send message
  $scope.send = function (message) {

    $scope.getMessages();

    // set a random image as user avatar - change this to match your structure
    var randomIndex = Math.round(Math.random() * (4));
    randomIndex++;
    $scope.avatar = 'img/users/' + randomIndex + '.jpg';
    // add new items to the array
    // the message is automatically added to our Firebase database!
    $scope.messages.$add({
      text: message,
      email: $rootScope.user,
      user: $rootScope.userUid,
      avatar: $scope.avatar
    });
    $scope.message = '';
  };

  function storeFolderImages(file) {

    var innerDeferred = $q.defer();

    //storeFolderImages(myfile, resolve);
    var storageRef = firebase.storage().ref().child('folder').child('images').child(file.name);
    // Upload file to Firebase Storage
    var uploadTask = storageRef.putString(file.thumbnailImage, 'data_url');
    uploadTask.on('state_changed', null, null, function () {
      var downloadUrl = uploadTask.snapshot.downloadURL;
      innerDeferred.resolve(downloadUrl);
    })
    // Set the download URL to the message box, so that the user can send it to the database
    //$scope.userDisplayPic = downloadUrl;
    return innerDeferred.promise;
  };
  $scope.saveFolder = function (folderInfo) {
    var deferred = $q.defer();
    var base64Array = [];
    if ($scope.folderArray.length > 0) {
      var uploadPromiseFolderImgs = $scope.folderArray.map(function (myfile, index) {
        var innerDeferred = $q.defer();

        //storeFolderImages(myfile, resolve);
        var storageRef = firebase.storage().ref().child('folder').child('images').child(myfile.name);
        // Upload file to Firebase Storage
        var uploadTask = storageRef.putString(myfile.thumbnailImage, 'data_url');
        uploadTask.on('state_changed', null, null, function () {
          var downloadUrl = uploadTask.snapshot.downloadURL;
          innerDeferred.resolve(downloadUrl);
        })
        // Set the download URL to the message box, so that the user can send it to the database
        //$scope.userDisplayPic = downloadUrl;
        return innerDeferred.promise;
      })
      $q.all(uploadPromiseFolderImgs).then(function (imageResolved) {
        console.log(imageResolved);
        var imgArrNames = [];
        var imagesObj = {};
        var j = 0;
        if (editFolderRef.images) {
          var alreadyHaveImagesLength = Object.keys(editFolderRef.images).length;
          for (var i = alreadyHaveImagesLength; i < imageResolved.length + alreadyHaveImagesLength; i++) {
            var imgArrNames = "image-" + i;
            var indexOfImgName = imgArrNames;
            var indexOfImgReslved = imageResolved[j];
            imagesObj[indexOfImgName] = indexOfImgReslved;
            editFolderRef.images[imgArrNames] = imageResolved[j];
            j++
          }
          editFolderRef.$save().then(function (ref) {
            ionicToast.show('Successfully edited the folder!.', 'bottom', false, 2500);
            console.log("Success:", ref);
          }, function (error) {
            console.log("Error:", error);
          });
          deferred.resolve(imageResolved)
        } else {
          for (var i = 0; i < imageResolved.length; ++i) {
            var imgArrNames = "image-" + i;
            var indexOfImgName = imgArrNames;
            var indexOfImgReslved = imageResolved[i];
            imagesObj[indexOfImgName] = indexOfImgReslved;
          }
          editFolderRef.images = {};
          editFolderRef.images = imagesObj;
          editFolderRef.$save().then(function (ref) {
            ionicToast.show('Successfully edited the folder!.', 'bottom', false, 2500);
            console.log("Success:", ref);
          }, function (error) {
            console.log("Error:", error);
          });
        }

      }).catch(function (err) {
        console.log(err);
        deferred.reject(err);
      })
    } else {
      editFolderRef.$save().then(function (ref) {
        ionicToast.show('Successfully edited the folder!.', 'bottom', false, 2500);
        console.log("Success:", ref);
      }, function (error) {
        console.log("Error:", error);
      });
    }
    /*var editedObject = {};
    editedObject = folderInfo;
    editedObject.images = editFolderRef.images;*/

    //console.log(folderInfo, $scope.folderArray);
    /*delete editedObject.$$conf;
    delete editedObject.$id;
    delete editedObject.$resolved;
    delete editedObject.$priority;*/

    //firebase.database().ref('folder/' + uuid).set(editedObject);
    /*  var uploadPromiseFolderImgs = $scope.folderArray.map(function (myfile, index) {
      var innerDeferred = $q.defer();

      //storeFolderImages(myfile, resolve);
      var storageRef = firebase.storage().ref().child('folder').child('images').child(file.name);
      // Upload file to Firebase Storage
      var uploadTask = storageRef.putString(file.thumbnailImage, 'data_url');
      uploadTask.on('state_changed', null, null, function () {
        var downloadUrl = uploadTask.snapshot.downloadURL;
        innerDeferred.resolve(downloadUrl);
      })
      // Set the download URL to the message box, so that the user can send it to the database
      //$scope.userDisplayPic = downloadUrl;
      return innerDeferred.promise;
    })
    $q.all(uploadPromiseFolderImgs).then(function (imageResolved) {
      console.log(imageResolved);
      var imgArrNames = [];
      var imagesObj = {};
      for (var i = 0; i < imageResolved.length; ++i) {
        imgArrNames[i] = "image-" + i;
        var indexOfImgName = imgArrNames[i];
        var indexOfImgReslved = imageResolved[i];
        imagesObj[indexOfImgName] = indexOfImgReslved;
      }
      folderInfo.images = imagesObj;
      var folderNode = $firebaseArray(folderRef);
      folderNode.$add(folderInfo).then(function (success) {
        console.log(success);
      });
      deferred.resolve(imageResolved)
    }).catch(function (err) {
      console.log(err);
      deferred.reject(err);
    })*/
  }
  $scope.saveData = function (user, msg, b64) {
    var pdfIsTrue = false;
    var userData = {};
    userData = $scope.user;
    // userData.body = extractLinkFromBody(userData.body)
    console.log(user, msg);
    userData.body = msg;
    userData.publish_date = new Date(userData.publish_date).getTime();
    userData.author = $rootScope.user;
    userData.category = $scope.categoryDropDown.selected;

    imgObj.base64 = b64;
    pdfDoc = pdfDoc[0].files[0];
    if (pdfDoc) {
      if (pdfDoc.name.indexOf('pdf') > -1) {
        pdfIsTrue = true;
      }
    }
    console.log(pdfDoc);

    var uploadPromiseImgs = new Promise(function (resolve, reject) {
      if (pdfIsTrue) {
        $scope.storePDFDocToDB(pdfDoc, resolve);
      } else {
        $scope.storeImageToDB(imgObj, resolve);
      }
    });
    Promise.all([uploadPromiseImgs]).then(function (data) {
      userData.img = downloadUrl;
      var ref = firebase.database().ref().child("userInfo");
      var userNode = $firebaseArray(ref);
      userNode.$add(userData).then(function (success) {
        var addedObjDetails = success.path.o;
        var addedObj = addedObjDetails[1];
        $state.go('app.edit', { 'id': addedObj })
        console.log(success);
        console.log(addedObj[1]);
      });
    }).catch(function (err) {
      console.log(err);
    })
  };
  var imgObj = {};
  $scope.myImage = '';
  $scope.myCroppedImage = '';

  var handleFileSelect = function (evt) {
    var file = evt.currentTarget.files[0];
    imgObj.name = file.name;
    var reader = new FileReader();
    reader.onload = function (evt) {
      $scope.$apply(function ($scope) {
        $scope.myImage = evt.target.result;
      });
    };
    reader.readAsDataURL(file);
  };
  angular.element(document.querySelector('#fileInput')).on('change', handleFileSelect);

})

app.controller('WeatherCtrl', function ($scope, $ionicLoading, weatherService) {

  $scope.getWeather = function () {
    weatherService.get().then(function (data) {
      $scope.weather = data;
    });
  }

})


app.controller('ContactCtrl', function ($scope) {


})



app.controller('YoutubeCtrl', function ($scope, $window, $sce, googleService, $stateParams, $ionicLoading) {

  $ionicLoading.show({
    template: 'Loading videos...'
  });

  $window.initGapi = function () {
    $scope.$apply($scope.getChannel);
  };

  $scope.getChannel = function () {
    googleService.googleApiClientReady().then(function (data) {
      $scope.videos = data.items;
      $scope.channel = data.items[0].snippet.channelTitle;
      $ionicLoading.hide();
    }, function (error) {
      console.log('Failed: ' + error)
    });
  };

  $scope.getVideoId = function () {
    $ionicLoading.show({
      template: 'Loading video...'
    });
    document.getElementById('video').src = 'https://www.youtube.com/embed/' + $stateParams.id;
    googleService.googleApiClientReady().then(function (data) {
      $scope.video = data.items[$stateParams.index];
      $ionicLoading.hide();
    }, function (error) {
      console.log('Failed: ' + error)
    });
  }

});



app.controller('MapsCtrl', function ($scope) {


})


app.controller('AdmobCtrl', function ($scope) {


  $scope.showBanner = function () {
    if (AdMob) AdMob.showBanner();
  }
  $scope.hideBanner = function () {
    if (AdMob) AdMob.hideBanner();
  }
  $scope.showInterstitial = function () {
    if (AdMob) AdMob.showInterstitial();
  }




})

app.controller('AskanexpertCtrl', function ($scope, $rootScope, $ionicLoading, FirebaseUser, Firebase, $firebaseObject, $firebaseArray) {


  $ionicLoading.show({
    template: 'Loading Firebase data...'
  });

  if (!Date.now) {
    Date.now = function () { return new Date().getTime(); }
  }

  // FIREBASE

  // object
  var URL = Firebase.url();

  var refObject = firebase.database().ref().child("questions"); // work with firebase url + object named 'data'
  // download the data into a local object
  var syncObject = $firebaseObject(refObject);
  // synchronize the object with a three-way data binding
  syncObject.$bindTo($scope, "firebaseObject"); // $scope.firebaseObject is your data from Firebase - you can edit/save/remove
  $ionicLoading.hide();


  // array
  var refArray = firebase.database().ref().child("questions");
  // create a synchronized array
  $scope.messages = $firebaseArray(refArray); // $scope.messages is your firebase array, you can add/remove/edit
  // add new items to the array
  // the message is automatically added to our Firebase database!
  $scope.addMessage = function (message) {
    $scope.newMessageText = null;
    $scope.messages.$add({
      question: message,
      email: $rootScope.user,
      date: Date(),
      user: $rootScope.userUid
    });


  };

})
