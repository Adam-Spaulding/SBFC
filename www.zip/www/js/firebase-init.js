
// Initialize Firebase
app.config(function() {
  var config = {
    apiKey: "AIzaSyCX_gH-ZsxFR4O4-91jJKAHGoTuHlIo1k0",
    authDomain: "sbfc-4f832.firebaseapp.com",
    databaseURL: "https://sbfc-4f832.firebaseio.com",
    storageBucket: "sbfc-4f832.appspot.com",
  };
  firebase.initializeApp(config);

      // Get a reference to the storage service, which is used to create references in your storage bucket
 // var storage = firebase.storage();

  // Create a storage reference from our storage service
//  var storageRef = storage.ref();
});
